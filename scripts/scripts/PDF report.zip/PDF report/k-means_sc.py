
##### 
### Scaled
### 
from sklearn.cluster import KMeans
from yellowbrick.cluster import SilhouetteVisualizer
from yellowbrick.datasets import load_nfl
import numpy as np

import pandas as pd
from sqlalchemy import create_engine

engine=create_engine("mysql+pymysql://root:189999@127.0.0.1:3306/reference")
df=pd.read_sql("""select * from kolachalama_data""", engine)
# Specify the features to use for clustering
FEATURES = ["bMI (Kg/m2)", "SBP", "Hb", "WBC", "Platelet", "BUN", "Creatinine",
            "egfr (MDRD)", "HCO3", "ph", "HbA1c", "LDL", "Tsat", "Ferritin","DBP","HDL","TG"]
num = df[FEATURES].apply(pd.to_numeric, errors="coerce").dropna()   # use dropna, not fillna(0)
rng = np.random.default_rng(42)
n_perm = 5000

def perm_p(x, y):
    xz = (x - x.mean()) / x.std()
    yz = (y - y.mean()) / y.std()
    r = (xz * yz).mean()
    null = np.array([(xz * rng.permutation(yz)).mean() for _ in range(n_perm)])
    return r, (1 + (np.abs(null) >= abs(r)).sum()) / (n_perm + 1)

cols = list(num.columns)
rows = [(a, b, *perm_p(num[a].to_numpy(), num[b].to_numpy()))
        for i, a in enumerate(cols) for b in cols[i+1:]]
res = pd.DataFrame(rows, columns=["a", "b", "r", "p"])

# Benjamini-Hochberg adjustment (FDR)
m = len(res)
order = np.argsort(res.p.to_numpy())
adj = res.p.to_numpy()[order] * m / np.arange(1, m + 1)
adj = np.minimum.accumulate(adj[::-1])[::-1].clip(max=1)
res.loc[res.index[order], "p_adj"] = adj

print(res[res.p_adj < 0.05].sort_values("r", key=abs, ascending=False)) ##### OK-- Creatinine and egfr are highly correlated, as expected.  HCO3 and ph (0.009 p_adj) 

#              a            b         r       p     p_adj
#28          SBP          DBP  0.832696  0.0002  0.005439 ***
#124         LDL          HDL  0.768740  0.0002  0.005439 ***
#81   Creatinine  egfr (MDRD) -0.732133  0.0002  0.005439 ***
#70          BUN   Creatinine  0.566662  0.0002  0.005439
#100        HCO3           ph  0.558314  0.0004  0.009065
#71          BUN  egfr (MDRD) -0.550273  0.0002  0.005439
#115       HbA1c          LDL  0.447383  0.0022  0.042734

SBP,DBP
LDL,HDL
Creatinine,egfr
BUN,creatinine
HCO3,ph
BUN,egfr
HbA1c,LDL
------------------------------------------------------------------------------------

# Specify the features to use for clustering
FEATURES = ["bMI (Kg/m2)", "SBP", "Hb", "WBC", "Platelet", "BUN", "Creatinine",
            "egfr (MDRD)", "HCO3", "ph", "HbA1c", "LDL", "Tsat", "Ferritin"]
df = df[FEATURES]

# Instantiate the clustering model and visualizer
model = KMeans(3, random_state=42)
visualizer = SilhouetteVisualizer(model, colors='yellowbrick')

visualizer.fit(df)        # Fit the data to the visualizer
visualizer.show()        # Finalize and render the figure
-----------------------------------------------------------------------------------

-----------------------------------------------------------------------------------

##### Alt.
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_samples, silhouette_score

k = 3
labels = KMeans(n_clusters=k, n_init=10, random_state=42).fit_predict(X)
sil = silhouette_samples(X, labels)
avg = silhouette_score(X, labels)

fig, ax = plt.subplots(figsize=(7, 5))
y_lower = 10
for i in range(k):
    vals = np.sort(sil[labels == i])
    y_upper = y_lower + len(vals)
    ax.fill_betweenx(np.arange(y_lower, y_upper), 0, vals, alpha=0.7, label=f"cluster {i}")
    y_lower = y_upper + 10
ax.axvline(avg, color="red", linestyle="--", label=f"mean = {avg:.2f}")
ax.set_xlabel("Silhouette coefficient")
ax.set_ylabel("Samples, grouped by cluster")
ax.legend()
plt.show()

import pandas as pd
from sqlalchemy import create_engine
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from yellowbrick.cluster import SilhouetteVisualizer

engine = create_engine("mysql+pymysql://root:189999@127.0.0.1:3306/reference")
df = pd.read_sql("select * from kolachalama_data", engine)

FEATURES = ["bMI (Kg/m2)", "SBP", "Hb", "WBC", "Platelet", "BUN", "Creatinine",
            "egfr (MDRD)", "HCO3", "ph", "HbA1c", "LDL", "Tsat", "Ferritin"]
X = df[FEATURES].apply(pd.to_numeric, errors="coerce").dropna()   # KMeans fails on NaN
X_scaled = StandardScaler().fit_transform(X)                       # equal weight per feature

model = KMeans(2, n_init=10, random_state=42)
model._estimator_type = "clusterer"        # fixes the Yellowbrick type check
visualizer = SilhouetteVisualizer(model, colors="yellowbrick")

visualizer.fit(X_scaled)
visualizer.show()

##### K=3
import pandas as pd
from sqlalchemy import create_engine
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from yellowbrick.cluster import SilhouetteVisualizer

engine = create_engine("mysql+pymysql://root:189999@127.0.0.1:3306/reference")
df = pd.read_sql("select * from kolachalama_data", engine)

FEATURES = ["bMI (Kg/m2)", "SBP", "Hb", "WBC", "Platelet", "BUN", "Creatinine",
            "egfr (MDRD)", "HCO3", "ph", "HbA1c", "LDL", "Tsat", "Ferritin"]
X = df[FEATURES].apply(pd.to_numeric, errors="coerce").dropna()   # KMeans fails on NaN
X_scaled = StandardScaler().fit_transform(X)                       # equal weight per feature

model = KMeans(3, n_init=10, random_state=42)
model._estimator_type = "clusterer"        # fixes the Yellowbrick type check
visualizer = SilhouetteVisualizer(model, colors="yellowbrick")

visualizer.fit(X_scaled)
visualizer.show()

##### K =4 
import pandas as pd
from sqlalchemy import create_engine
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from yellowbrick.cluster import SilhouetteVisualizer

engine = create_engine("mysql+pymysql://root:189999@127.0.0.1:3306/reference")
df = pd.read_sql("select * from kolachalama_data", engine)

FEATURES = ["bMI (Kg/m2)", "SBP", "Hb", "WBC", "Platelet", "BUN", "Creatinine",
            "egfr (MDRD)", "HCO3", "ph", "HbA1c", "LDL", "Tsat", "Ferritin"]
X = df[FEATURES].apply(pd.to_numeric, errors="coerce").dropna()   # KMeans fails on NaN
X_scaled = StandardScaler().fit_transform(X)                       # equal weight per feature

model = KMeans(4, n_init=10, random_state=42)
model._estimator_type = "clusterer"        # fixes the Yellowbrick type check
visualizer = SilhouetteVisualizer(model, colors="yellowbrick")

visualizer.fit(X_scaled)
visualizer.show()

-----------------------------------------------------------------------------------

visualizer.fit(X_scaled)

print(visualizer.silhouette_score_)       # average silhouette score (one number, -1 to 1)
print(visualizer.silhouette_samples_)     # one score per row (array)
print(visualizer.labels_)                 # cluster assigned to each row
print(visualizer.n_clusters_)             # number of clusters (3)

###To see them per cluster and per row, put them in a DataFrame:

python
import pandas as pd

scores = pd.DataFrame({
    "cluster": visualizer.labels_,
    "silhouette": visualizer.silhouette_samples_,
}, index=X.index)           # X is the dropna'd frame, so the index matches the original rows

print(scores.groupby("cluster")["silhouette"].agg(["count", "mean", "min"]))
print(scores.sort_values("silhouette").head(10))    # worst-fitting rows

###Rows with a negative score were probably assigned to the wrong cluster.

To join them back to your original data, including the features:

python
result = df.loc[X.index].assign(cluster=visualizer.labels_,
                                silhouette=visualizer.silhouette_samples_)

###If you used the plain scikit-learn version instead of Yellowbrick, the same numbers come from:

python
from sklearn.metrics import silhouette_score, silhouette_samples
avg = silhouette_score(X_scaled, labels)
per_row = silhouette_samples(X_scaled, labels)

###To compare different numbers of clusters:

python
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

for k in range(2, 7):
    labels = KMeans(k, n_init=10, random_state=42).fit_predict(X_scaled)
    print(k, round(silhouette_score(X_scaled, labels), 3))

###The average score is read roughly like this: above about 0.5 is a clear structure, 0.25 to 0.5 is weak, and below 0.25 means the clusters are not well separated. With about 50 rows and 14 features, expect low scores, and check that the clusters aren’t just one or two outlier rows.